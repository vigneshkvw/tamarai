
'use strict';
var mongoose = require('mongoose');

var TicketStatusMaster = new mongoose.Schema({
   
    TicketID: {
         type:  mongoose.Schema.ObjectId, 
         auto: true ,
        required: '{PATH} is required!'
      },
      TicketDecs: {
        type: String,
        trim: true,
        required: '{PATH} is required!'
      },
      Active: {
        type: Boolean,
        required: '{PATH} is required!'
      }
  },
  {
    timestamps: true
  });


  
module.exports = mongoose.model('TicketStatusMaster', TicketStatusMaster);
'use strict';
var async = require("async");
var tickets = require('../../../Database/schema/tickets');
const constant = require("../../config");

// J0Q9#YJk0+Qt
// id_rsa

module.exports.saveTicket = function (ticketData, res) {    
            var Ticket = new tickets(ticketData);
            Ticket.save(function (err, admin) {
        if (err) {
            res.send(err);
        } else {
            res.json({result:constant.Success});
        }
    });
};


module.exports.getTicket = function (ticketData, res) {
    tickets.find(ticketData, function(err, result) {
        if (err) throw err;
        else if(result.length){
            res.status(200).json({
                status: constant.Success,
                data : result
            });
        }
        else res.status(400).json({ status: constant.Failure,data:constant.NoData}) 
      });
};


module.exports.manualAllocate = function (ticketData, res) {
    tickets.find(ticketData, function(err, result) {
        if (err) throw err;
        else if(result.length){
            res.status(200).json({
                status: constant.Success,
                data : result
            });
        }
        else {
            var  sortByModifiedDate =  function (callback) {
                let SortQuery = { "updatedAt": 1}
                
                tickets.find({},function(err, result) {
                    if (err) throw callback(err);
                    else if(result.length){                        
                       let updateQuery=result[0];
                       callback(null,updateQuery)
                    }
                }).sort(SortQuery).limit(1)
            },
            allocateTicket =  function (data,callback) {
                console.log(data);
                data.Assignee = ticketData.Assignee

                var myquery = {customerID : data.customerID};
         var newvalues = {$set: {Assignee: data.Assignee} };
         tickets.update(myquery, newvalues, function(err, result) {
                if (err) throw callback(err);
                else if(result){
                 callback(null,data); 
                }               
              });
            },
            finalCallback =  function (data,callback) {
                if(err){
                    res.send({ 
                        Status:constant.Error,
                        message: err
                      })
                }else{
                    res.json({Status :constant.Success,data : callback})
                }
            };
            async.waterfall([sortByModifiedDate,allocateTicket],finalCallback)
        }
      });
};


    
    
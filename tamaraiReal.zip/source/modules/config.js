
const constant = {
    HTTP_PREFIX: 'http://',
    HTTPS_PREFIX: 'https://',
    InvalidUserID : "Please enter valid UserID",
    InvalidToken : "Please Login. Token Expired ",
    InvalidPassWord : "Please Enter valid Password",
    Error: "Error",
    NoData :"No Data Found",
    Success:"Success",
    Failure:"Failure" 
  };
  
  
  module.exports = constant;
  
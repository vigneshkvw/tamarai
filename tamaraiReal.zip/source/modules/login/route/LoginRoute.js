const express = require('express');
const router = express.Router();

    var {register , login ,TokenAuth,getUser} = require('../services/LoginController');
     

    router.post('/register', (req, res, next) => {
        if(req.body){
            register(req.body,res)
        }else{
            res.status(400).json({
            message: 'Invalid JSON'
        });
        }
    });


    router.post('/login', (req, res, next) => {
        if(req.body){
            login(req.body,res)
        }else{
            res.status(400).json({
            message: 'Invalid JSON'
        });
        }
    });

    router.get('/getUser', (req, res, next) => {
        var processBill =(err,data)=>{
            if(err){
                res.status(400).json({
                    message: err
                });
            }else if(data){
                if(req.query){
                    getUser(req.query,res)        
                }else{
                    res.status(400).json({
                        message: 'Query missing'
                    });
                }
            }          
        }
        TokenAuth(req.headers.token, processBill)
    });

    module.exports = router;
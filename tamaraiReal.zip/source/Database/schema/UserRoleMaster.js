
'use strict';
var mongoose = require('mongoose');

var userRoleSchema = new mongoose.Schema({
   
    RoleID: {
         type:  mongoose.Schema.ObjectId, 
         auto: true ,
        required: '{PATH} is required!'
      },
      RoleDecs: {
        type: String,
        trim: true,
        required: '{PATH} is required!'
      },
      Active: {
        type: Boolean,
        required: '{PATH} is required!'
      }
  },
  {
    timestamps: true
  });


  
module.exports = mongoose.model('UserRole', userRoleSchema);
const express = require('express');
const app = express();
const mongoose = require('mongoose');
const { mongoUrl } = require('../config');
const bodyParser = require('body-parser');

// declare schema

 
//routes 
 const LoginRoutes = require('./modules/login/route/LoginRoute');
 const superMartRoutes = require('./modules/SuperMart/route/superMartRoutes');
 const ticketRoutes = require('./modules/Product/route/ticketRoutes');



const option = { useNewUrlParser: true, useUnifiedTopology: true };

// var user = encodeURIComponent('dave');
// var password = encodeURIComponent('abc123');
// var authMechanism = 'DEFAULT';

// var url = format('mongodb://%s:%s@localhost:27017/telecalling?authMechanism=%s',
//   user, password, authMechanism);

mongoose.connect(mongoUrl, option);
mongoose.Promise = global.Promise;


 
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
 



app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header(
      "Access-Control-Allow-Headers",
      "Origin, X-Requested-With, Content-Type, Accept, Authorization"
    );
    if (req.method === "OPTIONS") {
      res.header("Access-Control-Allow-Methods", "PUT, POST, PATCH, DELETE, GET");
      return res.status(200).json({});
    }
    next();
});
 
 app.use('/Auth', LoginRoutes);
 app.use('/superMart', superMartRoutes);
 app.use('/Tickets', ticketRoutes);
// app.use('/books', booksRoutes);
 
module.exports = app;